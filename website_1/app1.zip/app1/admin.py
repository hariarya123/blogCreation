from django.contrib import admin
from .models import finepage,register

# Register your model with the admin site
admin.site.register(finepage)
admin.site.register(register)
